require 'rails_helper'

feature 'user mark recipe as feature' do
  scenario 'successfully' do
    Recipe.create(title: 'Bolo de cenoura', difficulty: 'Médio',
                  recipe_type: 'Sobremesa', cuisine: 'Brasileira',
                  cook_time: 50, ingredients: 'Farinha, açucar, cenoura',
                  cook_method: 'Cozinhe a cenoura, corte em pedaços pequenos, misture com o restante dos ingredientes')

    visit root_path
    click_on 'Bolo de cenoura'
    click_on 'Marcar como destaque'

    expect(page).to have_content('Receita marcada como destaque com sucesso!')
    expect(page).to have_css("img[src*='star']")
  end

  scenario 'and they appear differently' do
    Recipe.create(title: 'Bolo de cenoura', difficulty: 'Médio',
                  recipe_type: 'Sobremesa', cuisine: 'Brasileira',
                  cook_time: 50, ingredients: 'Farinha, açucar, cenoura',
                  cook_method: 'Cozinhe a cenoura, corte em pedaços pequenos, misture com o restante dos ingredientes',
                  featured: true)

    visit root_path

    expect(page).to have_css('h3', text: 'Receitas destaque')
    within '#recipes-featured' do
      expect(page).to have_css("img[src*='star']")
    end
  end
end
